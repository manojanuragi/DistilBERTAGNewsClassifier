
# DistilBERT AG News Classifier (CPU)

Fine-tunes `distilbert-base-uncased` on a balanced subset of AG News
(30,000 train / 3,000 test) to classify news into World, Sports, Business and Sci/Tech.

## Setup

```bash
pip install -r input_1_requirements.txt
```

## Run

```bash
python artifact_1_train_agnews_mps.py
```

## Outputs

- `outputs/distilbert-agnews/` – model.safetensors, config.json, tokenizer_config.json
- `outputs/final_output_1_classification_report.txt` – precision, recall, F1-score, accuracy
- `outputs/final_output_2_confusion_matrix.png` – confusion matrix chart


## Push to GitHub

```bash
git init
git add artifact_1_train_agnews_mps.py input_2_config.yaml input_1_requirements.txt artifact_2_README.md
git commit -m "DistilBERT AG News classifier"
git remote add origin https://github.com/your-username/agnews-distilbert.git
git push -u origin main
```